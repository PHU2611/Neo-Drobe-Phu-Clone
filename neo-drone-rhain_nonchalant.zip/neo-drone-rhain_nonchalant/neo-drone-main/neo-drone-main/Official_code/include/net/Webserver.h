#pragma once

void initWebServer();

